#!/usr/bin/env python
# from datetime import datetime,timedelta
from dateutil import tz
from geopy.distance import vincenty
from flask import render_template
from app import app
from flask import abort, redirect, url_for, flash, Flask, request
from twython import Twython, TwythonStreamer
import json, requests, humanize, string, psycopg2, pytz, copy
# import datetime
from datetime import datetime, timedelta
from FindUsers import *

# For connecting to Twitter Stream using OAuth 1
APP_KEY = 'GLIC9scXNOCQPMvW2Z3vDR0gP'
APP_SECRET = 'r4pxcSzlCyaHiTR5QFSpN20nLn24XXV06YL8gtxGUzc4wXhgLA'
ACCESS_TOKEN = '2875905140-02P20c7dHFDgb9yIE2jEqdlidS9xOGkdVq4nrGB'
ACCESS_TOKEN_SECRET = '42azhlc7p4Hi949NvPth3FmdJ8bZafzGqLIrAHKTXDOSi'

APP_KEY = 'UmLjRKeW4Gc9RlLUBqoNfpmyG'
APP_SECRET = 'qFCKEMZbLD7NO4ki2ksbibQ01SV88ECJQLZn3TQmQXiJkvN877'
ACCESS_TOKEN = '3307752328-R52HmpgczQt5tl8hYohaXZ9j0moNMOfAemNEdd1'
ACCESS_TOKEN_SECRET = 'eJNVo321y9Ancj08oJOo9Ii4KFHJIJgbyFSgaRuMGHb3x'

recentTweeters = []
class NEW_QUESTION: 
    # default values 
    city = "Pittsburgh"
    venue = "Schenley Plaza"
    usernames = ["jinnyhyunjikim"]
    question = "How many college students do you see at Schenley Plaza right now?"
    topic = "park usage"
    q_id = 0 # question_id in tweetdb
    

# twitter.verify_credentials()

class UserSearch:

    def __init__(self):
        self.minutes = None
        self.home_neighborhood = None
        self.last_tweet_venue_name  = None
        self.last_tweet_venue_id  = None
        self.last_tweet_streets = None
        self.search_result = { 'criteria': [], 'total_recent_tweet_count': 0, 'search_result': [],'query_duration': 0}

    def reset(self):
        print 'SEARCH RESET!'
        self.minutes = None
        self.home_neighborhood = None
        self.last_tweet_venue_name  = None
        self.last_tweet_venue_id  = None
        self.last_tweet_streets = None
        self.search_result = { 'criteria': [], 'total_recent_tweet_count': 0, 'search_result': [],'query_duration': 0}

class NewQuestion:

    def __init__(self):
        self.minutes = None
        self.home_neighborhood = None
        self.last_tweet_venue_name  = None
        self.last_tweet_venue_id  = None
        self.last_tweet_streets = None
        self.send_times = []
        self.search_result = { 'criteria': [], 'total_recent_tweet_count': 0, 'search_result': [],'query_duration': 0}

    def reset(self):
        print 'SEARCH RESET!'
        self.minutes = None
        self.home_neighborhood = None
        self.last_tweet_venue_name  = None
        self.last_tweet_venue_id  = None
        self.last_tweet_streets = None
        self.search_result = { 'criteria': [], 'total_recent_tweet_count': 0, 'search_result': [],'query_duration': 0}
        self.send_times = []



nq = NEW_QUESTION()
twitter = Twython(APP_KEY, APP_SECRET,
                  ACCESS_TOKEN, ACCESS_TOKEN_SECRET)
search = UserSearch()
new_question = NewQuestion()



def get_open_questions():
#    # Get questions that have not yet expired
#    # Returns a list of questions, each in dict format
    print 'getting questions'
    conn = psycopg2.connect(database="tweet", user="jinnyhyunjikim")
    cur = conn.cursor()
    statement = """SELECT question_id, question, location, subject,
    start_time, end_time, users_sent
    FROM question WHERE end_time > now() ORDER BY question_id DESC ; """
    statement = """SELECT question_id, question, location, start_time
    FROM question WHERE end_time > now() ORDER BY question_id DESC ; """
    statement = """SELECT question_id, question, subject, location, start_time, end_time, send_times
    FROM question ORDER BY question_id DESC ; """
    print statement
    cur.execute(statement)
    open_questions = cur.fetchall()
    conn.commit()
    cur.close()
    conn.close()
#
#        # Build dictionary for each question
    open_questions_list = [] # will insert each dictionary here
    print 'getting questions 2'
    columns = ('question_id', 'question', 'subject', 'location', 'start_time', 'end_time', 'send_times') 
    for question in open_questions:
        open_questions_list.append(dict(zip (columns, question)))
#
#        # Adjust to EST time (psql tweet stores UTC time)
#        for question in list_of_open_questions:
#            utc_time = question['created_at']
#            utc_time = str(utc_time)
#            est_time = convertUTCtoLocalTime(utc_time)
#            question['created_at'] = est_time
#
#        # Add replies to those tweets
#        for question in list_of_open_questions:
#            question_id = question['question_id']
#            replies = getRepliesForQuestion(question_id)
#            question['responses'] = replies # a list of dict of replies
#
    # print open_questions_list
    return open_questions_list




def sendTweet(user_to_ask, question_text):
    question_statement = "@" + user_to_ask + " " + question_text # e.g. '@jinny6235 Good afternoon!'
    print "SEDING TWEET!" + question_statement
    twitter.update_status(status = question_statement) # send tweet
    #sending duplicate tweet to same user as last one returns error 

    print " TWEET sent: " + user_to_ask + "!"
    print "updated database: QUESTION_TWEET"

# Insert data to psql tweet db
def updateDatabase(tablename, *data):
    columns_question = '(question_id, subject, question, expected_response_type, venue, city, created_at, expires_at)'
    columns_question = '(question_id, subject, location, question, start_time, end_time, send_times)'
    columns_question = '(question_id, subject, location, question, start_time, end_time)'
    columns_question = '(question_id, subject, location, question)'
    columns_response = '(response_id, response_raw, response_parsed, in_reply_to, user_id, created_at)'
    columns_question_tweet = '(tweet_id, question_id, user_id)'
    columns_question_user = '(user_id)'

    conn = psycopg2.connect(database="tweet", user="jinnyhyunjikim")
    cur = conn.cursor()

    data = list(data)
    data = tuple(data) 
    values = str(data)

    print 'updating db'
    if tablename == 'question_response':
        columns = str(columns_response)
    elif tablename == 'question':
        columns = str(columns_question)  
        # values = str(data)[:-1]+ ',%s)'
    elif tablename == 'question_user':
        columns = str(columns_question_user)
    elif tablename == 'question_tweet':
        columns = str(columns_question_tweet)
    else:
        print "Error: No such table to update!"

    statement = "INSERT INTO " + tablename + " " + columns + " VALUES " + values + ";"
    statement = "INSERT INTO " + tablename + " " + columns + " VALUES " + values + ";"
    print statement
    # cur.execute(statement)
    # print new_question.send_times
    if tablename == 'question':
        # cur.execute(statement, (new_question.send_times,))
        cur.execute(statement)
    else:
        cur.execute(statement)
    conn.commit()
    cur.close()
    conn.close()

# Get next unique id for new row in question and question_user
# question_tweet and question_user use id from twitter
def getNextRowID(tablename):
    # Connect to response table in the database
    conn = psycopg2.connect("dbname=tweet user=jinnyhyunjikim")
    cur = conn.cursor()

    # Query the response_id of the last element
    if tablename == 'question':
        print "querying for question"
        query = "SELECT max(question_id) FROM question;"
    elif tablename == 'question_user':
        query = "SELECT max(user_id) FROM question_user;"
    else:
        print "Error: No such table in psql tweet database."
        return

    cur.execute(query)
    result = cur.fetchone()


    largest_id = result[0]
    if largest_id == None: # table empty
        return 0
    return largest_id + 1

def getCorrespondingTweetIds(question_id):
    # returns a list of tweet_id's sending out the question
    conn = psycopg2.connect(database="tweet", user="jinnyhyunjikim")
    cur = conn.cursor()
    query = "SELECT tweet_id FROM question_tweet WHERE question_id = %s;" % (question_id)
    cur.execute(query)
    tweet_ids = list_of_corresponding_tweets = cur.fetchall() # returns a 2d list
    tweet_ids = [first_element for first_element, in tweet_ids]
    return tweet_ids

def getRepliesToATweet(tweet_id):
    # returns a list of replies made to a given tweet, identified by its tweet id
    # each reply is made into a dictionary
    conn = psycopg2.connect(database="tweet", user="jinnyhyunjikim")
    cur = conn.cursor()
    print "getting replies"
    # statement = """SELECT response_id, response_raw, response_parsed, question_response.user_id, question_response.created_at FROM question_response INNER JOIN question_tweet ON (question_tweet.tweet_id = question_response.in_reply_to) WHERE (question_tweet.tweet_id = %s) ; """ % (tweet_id)
    statement = """SELECT response_id, response_raw, response_parsed, question_response.user_id, question_id, created_at FROM question_response INNER JOIN question_tweet ON (question_tweet.tweet_id = question_response.in_reply_to) WHERE (question_tweet.tweet_id = %s) ; """ % (tweet_id)
    print 'statement : ' + statement
    cur.execute(statement)

    columns = ('response_id', 'response_raw', 'response_parsed', 'user_id', 'question_id', 'created_at' )
    replies = cur.fetchall()
    results = []
    for reply in replies:
        results.append(dict(zip (columns, reply)))
    conn.commit()
    cur.close()
    conn.close()
    return results

def getResponsesForQuestion(question_id):
    # Given question_id, get all tweet responses to that question.
    # 1. Get all tweet_id's sending out that question.
    # 2. Get all tweet_responses replying to those tweets.
    all_replies = []
    tweet_ids = getCorrespondingTweetIds(question_id)
    print "getting corresponding tweet ids " 
    print tweet_ids

    for one_tweet in tweet_ids:
        replies = getRepliesToATweet(one_tweet)
        all_replies += replies
    
    return all_replies

def getDistance(coordinates1, coordinates2):
# Takes in two tuples of lat/long points and calculates 
# Returns the distance in miles.
    distance = vincenty(coordinates1, coordinates2).miles
    return distance

# def removeDecimalPointInSeconds(timestamp_string):
# # takes in '2015-07-07 15:08:03.745033'
# # returns 2015-07-06 15:15:13.391368+00:00

#     seconds_decimal_point = timestamp_string.index(".")
#     timestamp_string = timestamp_string[:seconds_decimal_point]

# Convert UTC timestamp created by db to local (EST) time
def convertUTCtoLocalTime(timestamp_string):
    
    # remove decimal point in seconds
    seconds_decimal_point = timestamp_string.index(".")
    timestamp_string = timestamp_string[:seconds_decimal_point]

    # METHOD 1: Hardcode zones:
    from_zone = tz.gettz('UTC')
    to_zone = tz.gettz('America/New_York') # for EST

    # METHOD 2: Auto-detect zones:
    # from_zone = tz.tzutc()
    # to_zone = tz.tzlocal()

    # utc = datetime.utcnow()
    utc = datetime.datetime.strptime(timestamp_string, '%Y-%m-%d %H:%M:%S')

    # Tell the datetime object that it's in UTC time zone since 
    # datetime objects are 'naive' by default
    utc = utc.replace(tzinfo=from_zone)

    # Convert time zone
    eastern = utc.astimezone(to_zone)
    return eastern

# Start of web app code
@app.route('/')
@app.route('/index')
def index():
    print "loading index page"
    user = {'nickname': 'City of Pittsburgh'}
    posts = [
        {
            'author': {'nickname': 'John'},
            'body': 'Beautiful day in Portland!'
        },
        {
            'author': {'nickname': 'Susan'},
            'body': 'The Avengers movie was so cool!'
        }
    ]
    return render_template("index.html",
                           title='Home',
                           user=user,
                           open_questions=posts,
                           closed_questions=posts)



@app.route('/question')
def question():


# 1. Pass in open questions
# 2. Pass in closed questions
# 3. Pass in tweets sent
    open_questions = get_open_questions()
    print 'GOT OPEN QUESTIONS'
    # print open_questions
    return render_template('question.html', open_questions= open_questions)

# 
    # user = {'nickname': 'Miguel'}
    # posts = [
    #     {
    #         'author': {'nickname': 'John'},
    #         'body': 'Beautiful day in Portland!'
    #     },
    #     {
    #         'author': {'nickname': 'Susan'},
    #         'body': 'The Avengers movie was so cool!'
    #     }
    # ]
    # return render_template("question.html",
    #                        title='Question page',
    #                        user=user,
    #                        posts=posts)

def getRelativeTime(timestamp):
# Takes in a timestamp with timezone and
# returns humanized form of time difference btwn now and then
    timestamp = timestamp.replace(tzinfo=None) # strip timezone 
    now =  datetime.datetime.now()
    relativeTime = humanize.naturaltime( now - timestamp )
    return relativeTime

def get_responses():

    print 'getting parsed responses'
    conn = psycopg2.connect(database="tweet", user="jinnyhyunjikim")
    cur = conn.cursor()

    statement = """SELECT response_id, response_parsed, question.location, question.subject, user_id
    FROM question_response 
    INNER JOIN question ON question.question_id = question_response.question_id
    ORDER BY question.question_id DESC ; """
    print statement
    cur.execute(statement)
    responses = cur.fetchall()
    conn.commit()
    cur.close()
    conn.close()

    responses_list = [] # will insert each dictionary here
    print 'getting questions 2'
    columns = ('response_id', 'response_parsed', 'location', 'subject', 'username') 
    for response in responses:
        responses_list.append(dict(zip (columns, response)))

    print 'RESPONSES PARSED ==='
    print responses_list
    return responses_list


@app.route('/responses')
def responses():
    print 'rendering responses page'
    # user = {'nickname': 'Miguel'}
    # responses = [
    #     {
    #         'author': {'nickname': 'John'},
    #         'body': 'Beautiful day in Portland!'
    #     },
    #     {
    #         'author': {'nickname': 'Susan'},
    #         'body': 'The Avengers movie was so cool!'
    #     }
    # ]
    responses = get_responses()
    print 'GOT PARSED RESPONSES!'
    return render_template("responses_parsed.html", responses= responses)
    return render_template("responses.html",
                           title='Responses page',
                           user=user,
                           questions=open_questions,
                           closed_questions=closed_questions)

@app.route('/search_users')
def search_users():
    print 'here, in recent_tweets html page'
    users = { 'username' : 'jinnyhyunjikim' }
    # recent_tweeters = recentTweeters
    # print recent_tweeters
    # if request.method == 'POST':
    #     venue_name = str(request.form['venue_name'])
    #     print 'HERE!!!! VENUE NAME'
    #     print venue_name
    #     recent_tweeters = find_the_tweeters(venue_name)
    #     render_template('recent-tweeters.html', users=users)
    # else:
    #     print 'here'
    #     return render_template('recent-tweeters.html')
    return render_template('search_users.html', users=[])

@app.route('/show_recent_tweeters' )
def show_recent_tweeters():

    print 'now SHOW TWEETERS rendering page'
    result = search.search_result
    # result_str = json.dumps(result)
    result_str = copy.deepcopy(result)
    print result_str

    # for tweets in result['search_result']: # if also getting text
    #     tweets['text'] = tweets['text'].decode('utf-8')

    print 'now SHOW TWEETERS rendering page'
    criteria = get_criteria_str(result['criteria'])
    print 'after === '
    print result_str['search_result']
    print 'TWEET COUNT' + str(result['total_recent_tweet_count'])
    print type(result['total_recent_tweet_count'])
    print len(result['search_result'])
    print 'qeury duration ' + str(result['query_duration'] )
    print criteria

    search.reset()
    print 'now SHOW TWEETERS rendering page'
    # return render_template('show_recent_tweeters.html', 
    #         users=result['search_result'])
    return render_template('show_recent_tweeters.html', 
        users=result['search_result'], 
        total_tweeters=result['total_recent_tweet_count'],
        return_count=len(result['search_result']), 
        query_duration=str(result['query_duration']), 
        criteria=criteria)
        # result_str=result_str['search_result'])

def get_criteria_str(list_of_criteria):
# 
    return 'You searched for tweeters who tweeted within last x minutes near x who is most likely a resident of'
# def criteria_to_string(list):/
    # ['home', 'venue-id'] -> home, neighbor
def find_the_tweeters(venue_name= None):
    print 'finding the tweeters...'
    print 'venue name: ' + venue_name
    recentTweeters = FindUsers.search(last_tweet_venue_name = venue_name)
    return recentTweeters

@app.route('/show_answerers')
def show_answerers():
    # Get X number of people who tweeted at the area / venue within the past X minutes
    def getUsersToAsk(city = "tweet_pgh", venue = "Pittsburgh",
                                                     how_many = 2, type = "at"):
        return ["jinnyhyunjikim"] # testing

        city = "tweet_pgh" # or 'tweet_ny', 'tweet_sf', 'tweet_boston'
        search_limit = how_many
        venue = venue
        
        # query = """SELECT DISTINCT user_screen_name FROM %s 
        #             WHERE created_at >= (now() - interval '5 minutes') 
        #             AND place-> 'full_name' = '%s' limit %d""" % (city, _venue_, _search_limit_)
        query = """SELECT DISTINCT user_screen_name FROM %s 
                    WHERE created_at >= (now() - interval '5 minutes') 
                    limit %d;""" % ( city, search_limit )
        conn = psycopg2.connect(database="tweet", user="jinnyhyunjikim")
        cur = conn.cursor()
        cur.execute(query)
        result = cur.fetchall()
        conn.commit()
        cur.close()
        conn.close()
        return result

    def getUsersToAsk_method2(city = 'tweet_pgh', venue = 'Schenley Plaza',
                                                how_many = 5, type = 'park', nearby ="near"):
    # takes in a venue name and type, e.g. "Schenley Park", "park" or 
    # "Forbes+Craig","cross-section"

    # nearby = "near" - within .5 mi or "at" - within the bounding box 
    # returns a list of how_many users who tweeted NEAR that venue within
    # last X minutes
        # Get the coordinates of the venue
        return ['jinnyhyunjikim']
        def getVenueID(venue_name):

        	return
        def getCoordinatesOfVenue(venue_name):

	        CLIENT_ID ='0015X0KQ1MLXKW0RTDOCOKUMACBCKE30ZY2IFYPCQDYTZ3EC'
	        CLIENT_SECRET = 'UKJRW30YZAXC5DUO5KOZFPM4XWD3O3YSK0ANCZKB3TYCMCA5'

	        url = 'https://api.foursquare.com/v2/venues/search?match=true&limit=1'
	        city = 'near=%s' % ( 'pittsburgh,pa' )
	        venue_name = 'query=%s' % ( venue ) 	        # print venue_name
	        client_id = 'client_id=' + CLIENT_ID
	        client_secret = 'client_secret='+ CLIENT_SECRET
	        url_complete = url + '&' + city + '&' + venue_name + '&' + client_id + '&' + client_secret+'&v=20150707'
	        # client_secret = '&client_secret='+ CLIENT_SECRET&v=YYYYMMDD
	        # oauth_token = '%oauth_token=' + 'SIVKZ0OBXJOO5DO3IJUZ2YDHGEBO4RCY3O3DVJTUE0IN1STQ&v=20150707' 

	        # url = 'https://api.foursquare.com/v2/venues/search?near=New+Delhi&intent=browse&radius=10000&limit=10&query=pizza+hut' + client_id + '&' + client_secret + '&v=20150707'
	        
	        response = requests.get(url_complete)
	        response = response.json()

	        print 'queried!'

	        # check the query is valid
	        valid = response['meta']['code']
	        if valid == 200:
	            first_venue = response['response']['venues'][0]
	            first_venue_id = first_venue['id']
	            first_venue_location = first_venue['location']
	            keys = first_venue_location.keys()

	            latitude = first_venue_location['lat']

	            longitude = first_venue_location['lng']
	            # print type(latitude)

	            return (latitude, longitude)
	        else: 
	            print 'No location found. Please check the venue name'
	            return -1

        # Get users whose location within X minutes was within Y miles 
        # of the venue's coordinates
        coordinates_venue = getCoordinatesOfVenue(venue)
        if coordinates_venue == -1:
        	return
        else:
        	users_near = getNearUsers(coordinates_venue)

        def getUsersNearby(coordinate_points):
        # Takes in a tuple of latitude and longitude points and 
        # Returns a list of users from question_user db who has tweeted 
        # within X mi of the given points in the last 5 minutes

        	# Get users who tweeted within the last 5 minutes
            search_limit = 5
            query = """SELECT user_id FROM question_user
                        WHERE last_tweet_timestamp >= (now() - interval '5 minutes') 
                        limit %d;""" % ( search_limit )
            conn = psycopg2.connect(database="tweet", user="jinnyhyunjikim")
            cur = conn.cursor()
            cur.execute(query)
            recent_tweeters = cur.fetchall()  # -> get list of userids
            conn.commit()
            cur.close()
            conn.close()
            

        	# Filter users who were within X mi of the given points
            users_nearby = []
            proximity = 0.05 # miles
            # for recent_tweeter in recent_tweeters:
                # get last coordinates of the tweeter 
                # coordinates_tweeter = getMostRecentLocation

                # calculate distance
                # distance = getDistance(coordinates_venue, coordinates_tweeter)
                # if distance < proximity:
                    # users_nearby.append(recent_tweeter)
            return users_nearby


    # nq.usernames = getUsersToAsk()
    nq.usernames = getUsersToAsk_method2()
    usernames_to_display = []
    one_username = dict()
    for username in nq.usernames:
            one_username['username'] = username
            usernames_to_display.append(one_username)

    count = len(usernames_to_display)
    return render_template('show_answerers.html', venue=nq.venue, count=count, 
                usernames=usernames_to_display) 

def perdelta(start, end, delta):
# start, end = date/time/datetime
# delta = timedelta
    print 'in perdelta'
    times = []
    curr = start
    while curr < end:
        print str(curr)
        times.append(curr)

        curr += delta
    return times


# Store city, venue, question, and topic values given by the user
@app.route('/answerers', methods=['POST'])
def answerers():
    error = None
    nq.city = str(request.form['city'])
    nq.venue = str(request.form['venue'])
    nq.question = str(request.form['question'])
    nq.topic = str(request.form['topic'])
    nq.q_id =  getNextRowID("question") # incremental question_id in db
    return redirect(url_for('show_answerers'))
#    return render_template(url_for('show_answerers')) # does not work
#    return render_template(url_for('show_answerers.html')) # does not work
#    return redirect(url_for('show_answerers'))

@app.route('/enqueue_question', methods=['POST']) ## old 
def enqueue_question():
    print 'here'
    new_question.minutes = str(request.form['minutes'])
    new_question.subject = str(request.form['subject'])
    new_question.question = str(request.form['question'])

    try: # query may or may not include last tweet location as a search criterion
        if request.form['location'] == 'venue-name': location = new_question.last_tweet_venue_name = str(request.form['venue-name'])
        if request.form['location'] == 'venue-id': location = new_question.last_tweet_venue_id = str(request.form['venue-id'])

        if request.form['location'] == 'streets': 
            street_1, street_2 = str(request.form['venue-street-1']), str(request.form['venue-street-2'])
            # street_1, street_2 = request.form['venue-street-1']), str(request.form['venue-street-2'])
            streets = '%s & %s' % (street_1, street_2)
            location = new_question.last_tweet_streets = streets
    except: 
        pass


    new_question.start_time = start_time = str(request.form['start_time']) # '2000-01-01T05:00'
    new_question.end_time = end_time = str(request.form['end_time'])
    start_time = datetime.strptime(start_time, '%Y-%m-%dT%H:%M')
    end_time = datetime.strptime(end_time, '%Y-%m-%dT%H:%M')

    # start_time = datetime.strptime(start_time, '%Y-%m-%dT%H:%M')
    # end_time = datetime.strptime(end_time, '%Y-%m-%dT%H:%M')
    print 'START TIMEE'
    print start_time

    print 'before delta'
    delta = timedelta(minutes=5)
    print delta

    print 'got delta!'
    print type(start_time)
    print type(end_time)
    print type(delta)
    send_times = new_question.send_times = perdelta(start_time, end_time, delta)
    print 'sedding'

    # new_question.start_time = start_time
    # new_question.end_time = end_time
    # print new_question.end_time
    print 
    print '== NEW QUESTION == '
    print 

    print new_question.minutes
    print new_question.start_time
    print new_question.end_time
    print new_question.question
    print new_question.last_tweet_venue_name 
    print new_question.last_tweet_venue_id 
    print new_question.last_tweet_streets
    print ' == new question END'
    print 
    q_id = 1
    subject = str(new_question.subject)
    question = new_question.question
    # start_time = new_question.start_time
    # end_time = new_question.end_time
    print location
    print type(send_times)

    # updateDatabase("question", q_id, subject, location, question, start_time, end_time)
    updateDatabase("question", q_id, subject, location, question)
    print 'questio ndb updated!'

    # columns_question = '(question_id, subject, location, question, start_time, end_time)'

    # search.search_result = FindUsers.search(  
    #             within_x_minutes = search.minutes,
    #             home_neighborhood = search.home_neighborhood ,
    #             last_tweet_neighborhood = search.home_neighborhood ,
    #             last_tweet_venue_name = search.last_tweet_venue_name ,
    #             last_tweet_venue_id = search.last_tweet_venue_id,
    #             last_tweet_streets = search.last_tweet_streets)
    return redirect(url_for('question'))


@app.route('/get_recent_tweeters', methods=['POST']) ## old 
def get_recent_tweeters():
    # print request.form['city']
    # print request.form['venue-name']
    # venue_name = str(request.form['venue-name'])

    # print 'HERE!!!! VENUE NAME'
    # print venue_name
    # nq.usernames = find_the_tweeters(venue_name)
    # print 'before redirecting'
    # print 'nq   ---->'
    # print nq.usernames

    search.minutes = request.form['minutes']
    search.home_neighborhood = request.form['home-neighborhood']
    print search.minutes
    print search.home_neighborhood 
    # search.last_tweet_venue_name = request.form['venue-name']
    # search.last_tweet_venue_id = request.form['venue-id']
    # search.last_tweet_streets = (request.form['venue-street-1'], request.form['venue-street-2'])

    # check only the ones that were checked
    checked_criteria = request.form.getlist('check') 

    if 'home-neighborhood' not in checked_criteria: search.home_neighborhood = None
    if 'tweet-since' not in checked_criteria: search.minutes = 10000
    print checked_criteria
    # last tweet location
    try: # query may or may not include last tweet location as a search criterion
        if request.form['tweet-location'] == 'venue-name': search.last_tweet_venue_name = request.form['venue-name']
        if request.form['tweet-location'] == 'venue-id': search.last_tweet_venue_id = request.form['venue-id']
        if request.form['tweet-location'] == 'streets': search.last_tweet_streets = (request.form['venue-street-1'], request.form['venue-street-2'])
    except: 
        pass

    print 'here'
    print search.minutes
    print search.home_neighborhood 
    print search.last_tweet_venue_name 
    print search.last_tweet_venue_id 
    print search.last_tweet_streets
    print 'end'

    search.search_result = FindUsers.search(  
                within_x_minutes = search.minutes,
                home_neighborhood = search.home_neighborhood ,
                last_tweet_neighborhood = search.home_neighborhood ,
                last_tweet_venue_name = search.last_tweet_venue_name ,
                last_tweet_venue_id = search.last_tweet_venue_id,
                last_tweet_streets = search.last_tweet_streets)
    return redirect(url_for('show_recent_tweeters'))
# UserSearch.last_tweet_neighborhood = 








# Send questions to individual user
@app.route('/send_question', methods=['POST'])
def send_question():
    q_id = nq.q_id
    city = nq.city 
    venue = nq.venue
    question = nq.question
    topic = nq.topic
    tor = type_of_response = "numeric" # only numberic supported now with response db
    
    expire_after = 30 # minutes
    datetime_now = datetime.datetime.now()
    datetime_expire = datetime_now + datetime.timedelta(minutes=expire_after)
    datetime_now = str(datetime_now) # e.g. '2015-07-04 17:23:42.636711'
    datetime_expire = str(datetime_expire)
    datetime_expire = '2015-07-10 17:23:42.636711' # extended for testing

    print "updating database: QUESTION ... "
    # Insert this asking instance to question db
    updateDatabase("question", q_id, topic, question,
                            tor, venue, city, datetime_now, datetime_expire)
    print "done updating database: QUESTION "

    # Send tweet to individual username
    # Each tweet instance gets collected and stored from twitter stream,
    # not when being sent
    usernames = nq.usernames
    for username in usernames:
    	x= 2
        sendTweet(username, question)
    return redirect(url_for('question_sent')) ### return to question sent! ?
@app.route('/parse')
def parse():
    return render_template('parse.html')


@app.route('/question_sent')
def question_sent():
    print 'entires '
    entries = [
        {'username': 'one'},
        {'username': 'two'}
    ]
    question = nq.question
    users = nq.usernames
    # time = current_time
    return render_template('question_sent.html', question=question, users=users)


